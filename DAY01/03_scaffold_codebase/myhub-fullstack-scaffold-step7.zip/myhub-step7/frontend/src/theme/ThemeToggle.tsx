import { Button } from '../components/ui/Button'
import { useTheme } from './ThemeProvider'

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme()

  return (
    <Button
      type="button"
      variant="outline"
      onClick={toggleTheme}
      aria-label="테마 전환"
      title={theme === 'dark' ? '라이트 모드로 전환' : '다크 모드로 전환'}
    >
      {theme === 'dark' ? '다크' : '라이트'}
    </Button>
  )
}
