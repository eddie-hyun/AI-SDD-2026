import { AuthProvider } from './features/auth/AuthContext'
import { ThemeProvider } from './theme/ThemeProvider'
import { Header } from './layout/Header'
import { ProfileSection } from './features/profile/ProfileSection'
import { EducationSection } from './features/education/EducationSection'
import './App.css'

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Header />
        <main className="app-main">
          <ProfileSection />
          <EducationSection />
        </main>
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App
