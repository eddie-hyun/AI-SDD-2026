import { useEffect, useState } from 'react'
import { Button } from '../components/ui/Button'
import { useAuth } from '../features/auth/AuthContext'
import { LoginForm } from '../features/auth/LoginForm'
import { ThemeToggle } from '../theme/ThemeToggle'
import './Header.css'

export function Header() {
  const { isAuthenticated, isCheckingSession, sessionExpiredNotice, logout } = useAuth()
  const [showLoginForm, setShowLoginForm] = useState(false)

  // 다른 화면에서 세션 만료를 감지하면(reportSessionExpired), 헤더의 로그인 폼을 자동으로 연다.
  useEffect(() => {
    if (sessionExpiredNotice) {
      setShowLoginForm(true)
    }
  }, [sessionExpiredNotice])

  return (
    <header className="header">
      <div className="header__bar">
        <span className="header__title">MyHub</span>
        <div className="header__controls">
          <ThemeToggle />
          {!isCheckingSession &&
            (isAuthenticated ? (
              <Button type="button" variant="outline" onClick={() => void logout()}>
                로그아웃
              </Button>
            ) : (
              !showLoginForm && (
                <Button type="button" variant="ghost" onClick={() => setShowLoginForm(true)}>
                  관리자 로그인
                </Button>
              )
            ))}
        </div>
      </div>
      {!isAuthenticated && showLoginForm && (
        <div className="header__login">
          <LoginForm onSuccess={() => setShowLoginForm(false)} onCancel={() => setShowLoginForm(false)} />
        </div>
      )}
    </header>
  )
}
