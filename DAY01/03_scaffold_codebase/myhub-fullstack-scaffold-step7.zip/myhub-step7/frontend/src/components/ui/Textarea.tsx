import type { TextareaHTMLAttributes } from 'react'
import './ui.css'

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const classes = ['ui-field', className].filter(Boolean).join(' ')
  return <textarea className={classes} {...props} />
}
