import type { InputHTMLAttributes } from 'react'
import './ui.css'

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  const classes = ['ui-field', className].filter(Boolean).join(' ')
  return <input className={classes} {...props} />
}
