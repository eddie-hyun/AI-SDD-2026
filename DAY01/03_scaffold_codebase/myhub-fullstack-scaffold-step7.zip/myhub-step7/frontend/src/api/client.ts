import createClient from 'openapi-fetch'
import type { paths } from './schema'

// 모든 기능 패키지가 공유하는 단 하나의 openapi-fetch 클라이언트.
// 실제 엔드포인트 경로 문자열은 각 기능 패키지의 api.ts 안에서만 사용한다.
export const client = createClient<paths>({ baseUrl: '/api' })

/** 관리자 전용 요청이 401을 받았을 때 던지는 에러. 로그인 세션이 없거나 만료됐음을 나타낸다. */
export class SessionExpiredError extends Error {}
