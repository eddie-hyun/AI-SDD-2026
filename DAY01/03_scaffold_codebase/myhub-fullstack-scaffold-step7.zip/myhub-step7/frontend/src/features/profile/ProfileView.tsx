import type { Profile } from './api'
import './ProfileView.css'

interface ProfileViewProps {
  profile: Profile
}

export function ProfileView({ profile }: ProfileViewProps) {
  return (
    <div className="profile-view">
      <h1 className="profile-view__name">{profile.name}</h1>
      <p className="profile-view__headline">{profile.headline}</p>
      <p className="profile-view__bio">{profile.bio}</p>
      <p className="profile-view__updated-at">
        마지막 수정: {new Date(profile.updated_at).toLocaleString('ko-KR')}
      </p>
    </div>
  )
}
