import { useState } from 'react'
import type { FormEvent } from 'react'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { Textarea } from '../../components/ui/Textarea'
import { SessionExpiredError } from '../../api/client'
import { useAuth } from '../auth/AuthContext'
import { updateProfile } from './api'
import type { Profile } from './api'
import './ProfileEditForm.css'

interface ProfileEditFormProps {
  profile: Profile
  onSaved: (profile: Profile) => void
}

export function ProfileEditForm({ profile, onSaved }: ProfileEditFormProps) {
  const { reportSessionExpired } = useAuth()
  const [name, setName] = useState(profile.name)
  const [headline, setHeadline] = useState(profile.headline)
  const [bio, setBio] = useState(profile.bio)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsSaving(true)
    setError(null)
    try {
      const saved = await updateProfile({ name, headline, bio })
      onSaved(saved)
    } catch (err) {
      if (err instanceof SessionExpiredError) {
        reportSessionExpired()
        return
      }
      setError('저장하지 못했습니다. 다시 시도해주세요.')
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <form className="profile-edit-form" onSubmit={handleSubmit}>
      <Input
        className="profile-edit-form__name"
        value={name}
        onChange={(event) => setName(event.target.value)}
        placeholder="이름"
      />
      <Input value={headline} onChange={(event) => setHeadline(event.target.value)} placeholder="한 줄 소개" />
      <Textarea
        value={bio}
        onChange={(event) => setBio(event.target.value)}
        placeholder="상세 소개"
        rows={6}
      />
      <div className="profile-edit-form__actions">
        <Button type="submit" disabled={isSaving}>
          저장
        </Button>
      </div>
      {error && <p className="profile-edit-form__error">{error}</p>}
    </form>
  )
}
