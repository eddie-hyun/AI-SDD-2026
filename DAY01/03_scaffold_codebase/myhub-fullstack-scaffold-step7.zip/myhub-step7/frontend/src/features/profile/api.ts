import { client, SessionExpiredError } from '../../api/client'
import type { components } from '../../api/schema'

export type Profile = components['schemas']['ProfileResponse']
export type ProfileUpdateInput = components['schemas']['ProfileUpdateRequest']

/** 서버에 저장된 프로필(이름, 한 줄 소개, 상세 소개, 마지막 수정 시각)을 가져온다. */
export async function fetchProfile(): Promise<Profile> {
  const { data, error } = await client.GET('/profile')
  if (error || !data) {
    throw new Error('프로필 정보를 가져오지 못했습니다.')
  }
  return data
}

/** 로그인한 관리자가 프로필(이름, 한 줄 소개, 상세 소개)을 수정한다. 세션이 만료됐으면 SessionExpiredError를 던진다. */
export async function updateProfile(input: ProfileUpdateInput): Promise<Profile> {
  const { data, error, response } = await client.PUT('/profile', { body: input })
  if (response.status === 401) {
    throw new SessionExpiredError('로그인이 필요합니다.')
  }
  if (error || !data) {
    throw new Error('프로필을 저장하지 못했습니다.')
  }
  return data
}
