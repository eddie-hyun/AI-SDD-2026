import { useEffect, useState } from 'react'
import { Card } from '../../components/ui/Card'
import { useAuth } from '../auth/AuthContext'
import { fetchProfile } from './api'
import type { Profile } from './api'
import { ProfileView } from './ProfileView'
import { ProfileEditForm } from './ProfileEditForm'

export function ProfileSection() {
  const { isAuthenticated } = useAuth()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    fetchProfile()
      .then(setProfile)
      .catch(() => setError('프로필을 불러오지 못했습니다.'))
      .finally(() => setIsLoading(false))
  }, [])

  if (isLoading) {
    return <Card>불러오는 중...</Card>
  }

  if (error || !profile) {
    return <Card>{error ?? '프로필 데이터가 없습니다.'}</Card>
  }

  return (
    <Card>
      {isAuthenticated ? (
        <ProfileEditForm profile={profile} onSaved={setProfile} />
      ) : (
        <ProfileView profile={profile} />
      )}
    </Card>
  )
}
