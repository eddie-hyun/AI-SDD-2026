import { createContext, useContext, useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { fetchSession, login as loginRequest, logout as logoutRequest } from './api'

interface AuthContextValue {
  isAuthenticated: boolean
  isCheckingSession: boolean
  sessionExpiredNotice: string | null
  login: (password: string) => Promise<void>
  logout: () => Promise<void>
  /** profile/education 등 다른 기능이 401을 받았을 때 호출해, 로그인 상태를 전역적으로 되돌린다. */
  reportSessionExpired: () => void
  clearSessionExpiredNotice: () => void
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isCheckingSession, setIsCheckingSession] = useState(true)
  const [sessionExpiredNotice, setSessionExpiredNotice] = useState<string | null>(null)

  useEffect(() => {
    fetchSession()
      .then(setIsAuthenticated)
      .finally(() => setIsCheckingSession(false))
  }, [])

  async function login(password: string) {
    await loginRequest(password)
    setIsAuthenticated(true)
    setSessionExpiredNotice(null)
  }

  async function logout() {
    await logoutRequest()
    setIsAuthenticated(false)
  }

  function reportSessionExpired() {
    setIsAuthenticated(false)
    setSessionExpiredNotice('세션이 만료되었습니다. 다시 로그인해주세요.')
  }

  function clearSessionExpiredNotice() {
    setSessionExpiredNotice(null)
  }

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isCheckingSession,
        sessionExpiredNotice,
        login,
        logout,
        reportSessionExpired,
        clearSessionExpiredNotice,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth는 AuthProvider 안에서만 사용할 수 있습니다.')
  }
  return context
}
