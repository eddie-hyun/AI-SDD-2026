import { client } from '../../api/client'

/** 현재 요청에 유효한 관리자 세션이 있는지 확인한다. */
export async function fetchSession(): Promise<boolean> {
  const { data } = await client.GET('/auth/session')
  return data?.authenticated ?? false
}

/** 관리자 비밀번호로 로그인해 세션 쿠키를 발급받는다. 비밀번호가 틀리면 에러를 던진다. */
export async function login(password: string): Promise<void> {
  const { error, response } = await client.POST('/auth/login', { body: { password } })
  if (error || response.status === 401) {
    throw new Error('비밀번호가 올바르지 않습니다.')
  }
}

/** 세션 쿠키를 제거해 로그아웃한다. */
export async function logout(): Promise<void> {
  await client.POST('/auth/logout')
}
