import { useState } from 'react'
import type { FormEvent } from 'react'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { useAuth } from './AuthContext'
import './LoginForm.css'

interface LoginFormProps {
  onSuccess: () => void
  onCancel: () => void
}

export function LoginForm({ onSuccess, onCancel }: LoginFormProps) {
  const { login, sessionExpiredNotice, clearSessionExpiredNotice } = useAuth()
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsSubmitting(true)
    setError(null)
    try {
      await login(password)
      onSuccess()
    } catch {
      setError('비밀번호가 올바르지 않습니다.')
    } finally {
      setIsSubmitting(false)
    }
  }

  function handleCancel() {
    clearSessionExpiredNotice()
    onCancel()
  }

  return (
    <form className="login-form" onSubmit={handleSubmit}>
      {sessionExpiredNotice && <p className="login-form__notice">{sessionExpiredNotice}</p>}
      <Input
        type="password"
        value={password}
        onChange={(event) => setPassword(event.target.value)}
        placeholder="관리자 비밀번호"
        autoFocus
      />
      <div className="login-form__actions">
        <Button type="submit" disabled={isSubmitting}>
          로그인
        </Button>
        <Button type="button" variant="outline" onClick={handleCancel}>
          취소
        </Button>
      </div>
      {error && <p className="login-form__error">{error}</p>}
    </form>
  )
}
