import { useState } from 'react'
import { Button } from '../../components/ui/Button'
import { SessionExpiredError } from '../../api/client'
import { useAuth } from '../auth/AuthContext'
import { deleteEducation, updateEducation } from './api'
import type { Education, EducationInput } from './api'
import { EducationForm } from './EducationForm'
import './EducationItem.css'

interface EducationItemProps {
  education: Education
  onUpdated: (education: Education) => void
  onDeleted: (id: number) => void
}

function formatPeriod(startDate: string, endDate: string | null): string {
  return `${startDate} ~ ${endDate ?? '재학 중'}`
}

export function EducationItem({ education, onUpdated, onDeleted }: EducationItemProps) {
  const { isAuthenticated, reportSessionExpired } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [deleteError, setDeleteError] = useState<string | null>(null)

  async function handleUpdate(input: EducationInput) {
    try {
      const updated = await updateEducation(education.id, input)
      onUpdated(updated)
      setIsEditing(false)
    } catch (err) {
      if (err instanceof SessionExpiredError) {
        reportSessionExpired()
        return
      }
      throw err
    }
  }

  async function handleDelete() {
    setIsDeleting(true)
    setDeleteError(null)
    try {
      await deleteEducation(education.id)
      onDeleted(education.id)
    } catch (err) {
      if (err instanceof SessionExpiredError) {
        reportSessionExpired()
        return
      }
      setDeleteError('삭제하지 못했습니다.')
    } finally {
      setIsDeleting(false)
    }
  }

  if (isAuthenticated && isEditing) {
    return (
      <li className="education-item">
        <EducationForm initial={education} onCancel={() => setIsEditing(false)} onSubmit={handleUpdate} />
      </li>
    )
  }

  return (
    <li className="education-item">
      <div className="education-item__main">
        <p className="education-item__school">{education.school}</p>
        <p className="education-item__degree">{education.degree}</p>
        <p className="education-item__period">{formatPeriod(education.start_date, education.end_date)}</p>
        {education.description && <p className="education-item__description">{education.description}</p>}
      </div>
      {isAuthenticated && (
        <div className="education-item__actions">
          <Button type="button" variant="outline" onClick={() => setIsEditing(true)}>
            수정
          </Button>
          <Button type="button" variant="destructive" onClick={() => void handleDelete()} disabled={isDeleting}>
            삭제
          </Button>
        </div>
      )}
      {deleteError && <p className="education-item__error">{deleteError}</p>}
    </li>
  )
}
