import { useState } from 'react'
import type { FormEvent } from 'react'
import { Button } from '../../components/ui/Button'
import { Input } from '../../components/ui/Input'
import { Textarea } from '../../components/ui/Textarea'
import type { Education, EducationInput } from './api'
import './EducationForm.css'

interface EducationFormProps {
  initial?: Education
  onSubmit: (input: EducationInput) => Promise<void>
  onCancel: () => void
}

export function EducationForm({ initial, onSubmit, onCancel }: EducationFormProps) {
  const [school, setSchool] = useState(initial?.school ?? '')
  const [degree, setDegree] = useState(initial?.degree ?? '')
  const [startDate, setStartDate] = useState(initial?.start_date ?? '')
  const [endDate, setEndDate] = useState(initial?.end_date ?? '')
  const [description, setDescription] = useState(initial?.description ?? '')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsSubmitting(true)
    setError(null)
    try {
      await onSubmit({
        school,
        degree,
        start_date: startDate,
        end_date: endDate || null,
        description: description || null,
      })
    } catch {
      setError('저장하지 못했습니다. 다시 시도해주세요.')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form className="education-form" onSubmit={handleSubmit}>
      <Input value={school} onChange={(event) => setSchool(event.target.value)} placeholder="학교명" required />
      <Input
        value={degree}
        onChange={(event) => setDegree(event.target.value)}
        placeholder="학위 또는 전공"
        required
      />
      <div className="education-form__dates">
        <label className="education-form__date-field">
          <span>시작일</span>
          <Input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} required />
        </label>
        <label className="education-form__date-field">
          <span>종료일 (재학 중이면 비워두세요)</span>
          <Input type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} />
        </label>
      </div>
      <Textarea
        value={description}
        onChange={(event) => setDescription(event.target.value)}
        placeholder="추가 설명 (선택)"
        rows={3}
      />
      <div className="education-form__actions">
        <Button type="submit" disabled={isSubmitting}>
          저장
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          취소
        </Button>
      </div>
      {error && <p className="education-form__error">{error}</p>}
    </form>
  )
}
