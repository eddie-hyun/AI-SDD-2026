import { useEffect, useState } from 'react'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { SessionExpiredError } from '../../api/client'
import { useAuth } from '../auth/AuthContext'
import { createEducation, fetchEducationList } from './api'
import type { Education, EducationInput } from './api'
import { EducationForm } from './EducationForm'
import { EducationList } from './EducationList'
import './EducationSection.css'

export function EducationSection() {
  const { isAuthenticated, reportSessionExpired } = useAuth()
  const [entries, setEntries] = useState<Education[]>([])
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isAdding, setIsAdding] = useState(false)

  useEffect(() => {
    fetchEducationList()
      .then(setEntries)
      .catch(() => setError('학력 목록을 불러오지 못했습니다.'))
      .finally(() => setIsLoading(false))
  }, [])

  function handleUpdated(updated: Education) {
    setEntries((current) => current.map((entry) => (entry.id === updated.id ? updated : entry)))
  }

  function handleDeleted(id: number) {
    setEntries((current) => current.filter((entry) => entry.id !== id))
  }

  async function handleCreate(input: EducationInput) {
    try {
      const created = await createEducation(input)
      setEntries((current) => [created, ...current])
      setIsAdding(false)
    } catch (err) {
      if (err instanceof SessionExpiredError) {
        reportSessionExpired()
        return
      }
      throw err
    }
  }

  return (
    <Card className="education-section">
      <div className="education-section__header">
        <h2>학력</h2>
        {isAuthenticated && !isAdding && (
          <Button type="button" variant="outline" onClick={() => setIsAdding(true)}>
            추가
          </Button>
        )}
      </div>

      {isAuthenticated && isAdding && <EducationForm onCancel={() => setIsAdding(false)} onSubmit={handleCreate} />}

      {isLoading ? (
        <p>불러오는 중...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <EducationList entries={entries} onUpdated={handleUpdated} onDeleted={handleDeleted} />
      )}
    </Card>
  )
}
