import type { Education } from './api'
import { EducationItem } from './EducationItem'
import './EducationList.css'

interface EducationListProps {
  entries: Education[]
  onUpdated: (education: Education) => void
  onDeleted: (id: number) => void
}

export function EducationList({ entries, onUpdated, onDeleted }: EducationListProps) {
  if (entries.length === 0) {
    return <p className="education-list__empty">등록된 학력이 없습니다.</p>
  }

  return (
    <ul className="education-list">
      {entries.map((entry) => (
        <EducationItem key={entry.id} education={entry} onUpdated={onUpdated} onDeleted={onDeleted} />
      ))}
    </ul>
  )
}
