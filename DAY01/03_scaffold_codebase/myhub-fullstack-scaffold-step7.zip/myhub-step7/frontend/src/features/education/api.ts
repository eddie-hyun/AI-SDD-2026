import { client, SessionExpiredError } from '../../api/client'
import type { components } from '../../api/schema'

export type Education = components['schemas']['EducationResponse']
export type EducationInput = components['schemas']['EducationWriteRequest']

/** 모든 학력 항목을 시작일 최신순으로 가져온다. 로그인 여부와 관계없이 호출할 수 있다. */
export async function fetchEducationList(): Promise<Education[]> {
  const { data, error } = await client.GET('/education')
  if (error || !data) {
    throw new Error('학력 목록을 가져오지 못했습니다.')
  }
  return data
}

/** 로그인한 관리자가 새 학력 항목을 추가한다. 세션이 만료됐으면 SessionExpiredError를 던진다. */
export async function createEducation(input: EducationInput): Promise<Education> {
  const { data, error, response } = await client.POST('/education', { body: input })
  if (response.status === 401) {
    throw new SessionExpiredError('로그인이 필요합니다.')
  }
  if (error || !data) {
    throw new Error('학력 항목을 추가하지 못했습니다.')
  }
  return data
}

/** 로그인한 관리자가 기존 학력 항목을 수정한다. 세션이 만료됐으면 SessionExpiredError를 던진다. */
export async function updateEducation(id: number, input: EducationInput): Promise<Education> {
  const { data, error, response } = await client.PUT('/education/{education_id}', {
    params: { path: { education_id: id } },
    body: input,
  })
  if (response.status === 401) {
    throw new SessionExpiredError('로그인이 필요합니다.')
  }
  if (error || !data) {
    throw new Error('학력 항목을 수정하지 못했습니다.')
  }
  return data
}

/** 로그인한 관리자가 학력 항목을 삭제한다. 세션이 만료됐으면 SessionExpiredError를 던진다. */
export async function deleteEducation(id: number): Promise<void> {
  const { error, response } = await client.DELETE('/education/{education_id}', {
    params: { path: { education_id: id } },
  })
  if (response.status === 401) {
    throw new SessionExpiredError('로그인이 필요합니다.')
  }
  if (error) {
    throw new Error('학력 항목을 삭제하지 못했습니다.')
  }
}
