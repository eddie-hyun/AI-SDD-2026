import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 개발 서버(:5173)로 들어온 `/api`로 시작하는 요청을 백엔드(:8080)로 그대로 전달한다.
// 백엔드 라우트 자체는 `/api` 접두어가 없으므로(예: `/profile`), 전달 전에 `/api` 접두어를 떼어낸다.
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
})
