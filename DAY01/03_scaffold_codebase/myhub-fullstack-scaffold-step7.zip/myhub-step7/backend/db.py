"""SQLAlchemy 엔진과 세션을 초기화한다."""
import os
from collections.abc import Generator

from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.engine import make_url
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

load_dotenv()

# Supabase가 기본으로 주는 연결 문자열은 `postgresql://` 스킴이라 SQLAlchemy가
# (설치돼 있지 않은) psycopg2를 드라이버로 고르려 한다. 이미 설치된 psycopg(3)를 쓰도록
# 드라이버 이름만 `postgresql+psycopg`로 바꿔서 엔진을 만든다.
_url = make_url(os.environ["DATABASE_URL"])
if _url.drivername == "postgresql":
    _url = _url.set(drivername="postgresql+psycopg")

engine = create_engine(_url)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    """모든 엔티티 클래스가 상속하는 기본 클래스."""


def get_db() -> Generator[Session, None, None]:
    """요청마다 새 세션을 만들고, 요청이 끝나면 닫는 FastAPI 의존성."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
