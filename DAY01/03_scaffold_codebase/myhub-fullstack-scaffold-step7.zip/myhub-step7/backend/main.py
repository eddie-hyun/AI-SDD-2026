"""MyHub 백엔드 서버 진입점.

기능별 패키지(features/auth, features/profiles, features/education)의 라우터를
조립하는 역할만 담당한다. 각 기능의 엔드포인트·스키마·엔티티는 해당 패키지 안에 있다.
여기서는 그 외의, 특정 기능에 속하지 않는 관심사(앱 시작 시 테이블 생성/초기 데이터 삽입,
헬스체크)만 다룬다.
"""
import datetime
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from db import Base, SessionLocal, engine, get_db
from features.auth.router import router as auth_router
from features.education.models import Education
from features.education.router import router as education_router
from features.profiles.models import Profile
from features.profiles.router import router as profile_router


def _seed_initial_profile(db: Session) -> None:
    """profile 테이블이 비어 있으면(막 새로 만들어졌으면) 초기 데이터 1건을 넣는다."""
    if db.query(Profile).count() == 0:
        db.add(
            Profile(
                name="홍길동",
                headline="백엔드를 좋아하는 풀스택 개발자",
                bio="여기에 상세 소개를 자유롭게 작성하세요.",
            )
        )
        db.commit()


def _seed_initial_education(db: Session) -> None:
    """education 테이블이 비어 있으면(막 새로 만들어졌으면) 초기 데이터 1건을 넣는다."""
    if db.query(Education).count() == 0:
        db.add(
            Education(
                school="OO대학교",
                degree="컴퓨터공학 학사",
                start_date=datetime.date(2018, 3, 1),
                end_date=datetime.date(2022, 2, 28),
                description="여기에 학력에 대한 추가 설명을 자유롭게 작성하세요.",
            )
        )
        db.commit()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """서버 시작 시 엔티티 기준으로 없는 테이블을 만들고, 새로 생긴 테이블에는 초기 데이터를 채운다."""
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        _seed_initial_profile(db)
        _seed_initial_education(db)
    yield


app = FastAPI(title="MyHub API", lifespan=lifespan)

app.include_router(auth_router)
app.include_router(profile_router)
app.include_router(education_router)


@app.exception_handler(OperationalError)
def handle_database_error(request: Request, exc: OperationalError) -> JSONResponse:
    """DB 연결/쿼리 실패를 500 응답으로 변환한다. 엔드포인트마다 try/except를 반복하지 않기 위한 공통 처리."""
    return JSONResponse(status_code=500, content={"detail": f"데이터베이스 연결 실패: {exc}"})


class HealthResponse(BaseModel):
    """`/health` 응답 스키마. 서버와 DB가 정상적으로 연결되었는지를 나타낸다."""

    status: str = Field(description="서버 자체의 상태. 정상이면 'ok'")
    database_status: str = Field(description="Supabase DB와의 연결 상태. 정상이면 'connected'")
    database_version: str = Field(description="Supabase(PostgreSQL)가 SELECT version()으로 보고한 버전 문자열")


@app.get("/health", response_model=HealthResponse, tags=["health"])
def check_health(db: Session = Depends(get_db)) -> HealthResponse:
    """서버가 Supabase 데이터베이스와 실제로 통신 가능한지 확인한다.

    특정 기능에 속한 엔티티 조회가 아니므로 `SELECT version()`을 SQLAlchemy 세션으로
    직접 실행해, 연결 성공 여부와 데이터베이스 버전 문자열을 함께 반환한다.
    """
    version = db.execute(text("SELECT version()")).scalar_one()
    return HealthResponse(status="ok", database_status="connected", database_version=version)
