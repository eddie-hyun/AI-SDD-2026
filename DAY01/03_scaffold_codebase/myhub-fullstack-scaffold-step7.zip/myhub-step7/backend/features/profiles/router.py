"""profile 기능의 API 엔드포인트: 조회, 수정."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from db import get_db
from features.auth.service import require_admin

from .models import Profile
from .schemas import ProfileResponse, ProfileUpdateRequest

router = APIRouter(prefix="/profile", tags=["profile"])


@router.get("", response_model=ProfileResponse)
def get_profile(db: Session = Depends(get_db)) -> ProfileResponse:
    """DB에 저장된 프로필(이름, 한 줄 소개, 상세 소개, 마지막 수정 시각)을 조회한다.

    현재는 단일 사용자(본인 이력서)만 다루므로, id가 가장 작은 엔티티 하나를 조회한다.
    """
    profile = db.query(Profile).order_by(Profile.id).first()
    if profile is None:
        raise HTTPException(status_code=404, detail="프로필 데이터가 없습니다.")
    return ProfileResponse.model_validate(profile)


@router.put("", response_model=ProfileResponse)
def update_profile(
    payload: ProfileUpdateRequest,
    db: Session = Depends(get_db),
    _admin: None = Depends(require_admin),
) -> ProfileResponse:
    """로그인한 관리자가 프로필(이름, 한 줄 소개, 상세 소개)을 수정한다.

    id와 마지막 수정 시각(updated_at)은 클라이언트가 지정할 수 없다. updated_at은 Profile 엔티티의
    onupdate 규칙에 따라, 이 변경사항이 커밋되는 시점에 DB가 현재 시각으로 자동 갱신한다.
    """
    profile = db.query(Profile).order_by(Profile.id).first()
    if profile is None:
        raise HTTPException(status_code=404, detail="프로필 데이터가 없습니다.")

    profile.name = payload.name
    profile.headline = payload.headline
    profile.bio = payload.bio
    db.commit()
    db.refresh(profile)

    return ProfileResponse.model_validate(profile)
