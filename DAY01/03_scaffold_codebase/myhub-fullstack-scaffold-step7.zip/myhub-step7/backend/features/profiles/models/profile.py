"""profile 기능의 데이터베이스 엔티티."""
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from db import Base


class Profile(Base):
    """profile 테이블. 현재는 단일 사용자(본인 이력서) 정보만 담는다."""

    __tablename__ = "profile"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(Text)
    headline: Mapped[str] = mapped_column(Text)
    bio: Mapped[str] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
