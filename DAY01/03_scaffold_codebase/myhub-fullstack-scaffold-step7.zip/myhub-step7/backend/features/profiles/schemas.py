"""profile 기능의 API 요청/응답 DTO."""
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class ProfileResponse(BaseModel):
    """`/profile` 응답 스키마. Profile 엔티티 하나를 그대로 옮긴 것이다."""

    model_config = ConfigDict(from_attributes=True)

    name: str = Field(description="이름")
    headline: str = Field(description="한 줄 소개")
    bio: str = Field(description="상세 소개")
    updated_at: datetime = Field(description="마지막으로 프로필이 수정된 시각")


class ProfileUpdateRequest(BaseModel):
    """`PUT /profile` 요청 바디. id와 마지막 수정 시각은 서버가 자동으로 관리하므로 포함하지 않는다."""

    name: str = Field(description="이름")
    headline: str = Field(description="한 줄 소개")
    bio: str = Field(description="상세 소개")
