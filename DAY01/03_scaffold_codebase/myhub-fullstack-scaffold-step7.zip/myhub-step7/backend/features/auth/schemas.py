"""auth 기능의 API 요청/응답 DTO."""
from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    """`POST /auth/login` 요청 바디."""

    password: str = Field(description="관리자 비밀번호")


class SessionResponse(BaseModel):
    """로그인 상태 응답. 로그인/세션 확인/로그아웃 엔드포인트가 공통으로 사용한다."""

    authenticated: bool = Field(description="현재 요청에 유효한 관리자 세션이 있는지 여부")
