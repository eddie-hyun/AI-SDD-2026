"""세션 쿠키 서명·검증과 관리자 인증 로직.

profiles/education 등 다른 기능 패키지는 여기서 제공하는 `require_admin`을
관리자 전용 엔드포인트의 의존성으로 가져다 쓴다.
"""
import os

from dotenv import load_dotenv
from fastapi import HTTPException, Request
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

load_dotenv()

ADMIN_PASSWORD = os.environ["ADMIN_PASSWORD"]
SESSION_SECRET_KEY = os.environ["SESSION_SECRET_KEY"]

SESSION_COOKIE_NAME = "myhub_session"
SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 7  # 7일

serializer = URLSafeTimedSerializer(SESSION_SECRET_KEY)


def is_authenticated(request: Request) -> bool:
    """현재 요청에 유효한(서명이 맞고 만료되지 않은) 관리자 세션 쿠키가 있는지 확인한다."""
    token = request.cookies.get(SESSION_COOKIE_NAME)
    if token is None:
        return False
    try:
        serializer.loads(token, max_age=SESSION_MAX_AGE_SECONDS)
    except (BadSignature, SignatureExpired):
        return False
    return True


def require_admin(request: Request) -> None:
    """관리자 전용 엔드포인트 앞단에서 세션 쿠키를 검증하는 FastAPI 의존성.

    세션이 없거나 만료됐으면 401을 던져, FE가 이를 근거로 로그인 화면으로 안내할 수 있게 한다.
    """
    if not is_authenticated(request):
        raise HTTPException(status_code=401, detail="로그인이 필요합니다.")
