"""auth 기능의 API 엔드포인트: 로그인, 세션 확인, 로그아웃."""
from fastapi import APIRouter, HTTPException, Request, Response

from .schemas import LoginRequest, SessionResponse
from .service import (
    ADMIN_PASSWORD,
    SESSION_COOKIE_NAME,
    SESSION_MAX_AGE_SECONDS,
    is_authenticated,
    serializer,
)

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login", response_model=SessionResponse)
def login(payload: LoginRequest, response: Response) -> SessionResponse:
    """관리자 비밀번호를 확인하고, 일치하면 서명된 세션 쿠키를 응답에 실어 보낸다.

    이후 요청은 이 쿠키가 있어야 관리자 전용 기능(예: `PUT /profile`, `POST /education`)을
    사용할 수 있다.
    """
    if payload.password != ADMIN_PASSWORD:
        raise HTTPException(status_code=401, detail="비밀번호가 올바르지 않습니다.")

    token = serializer.dumps({"admin": True})
    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=token,
        max_age=SESSION_MAX_AGE_SECONDS,
        httponly=True,
        samesite="lax",
    )
    return SessionResponse(authenticated=True)


@router.get("/session", response_model=SessionResponse)
def get_session(request: Request) -> SessionResponse:
    """현재 요청에 유효한 관리자 세션 쿠키가 있는지 확인한다.

    프론트엔드가 새로고침 직후 로그인 상태를 복원할 때 사용한다.
    """
    return SessionResponse(authenticated=is_authenticated(request))


@router.post("/logout", response_model=SessionResponse)
def logout(response: Response) -> SessionResponse:
    """세션 쿠키를 제거해 로그아웃 처리한다."""
    response.delete_cookie(SESSION_COOKIE_NAME)
    return SessionResponse(authenticated=False)
