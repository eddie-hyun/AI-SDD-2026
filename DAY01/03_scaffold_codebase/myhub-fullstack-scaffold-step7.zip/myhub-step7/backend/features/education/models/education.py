"""education 기능의 데이터베이스 엔티티."""
from datetime import date

from sqlalchemy import BigInteger, Date, Text
from sqlalchemy.orm import Mapped, mapped_column

from db import Base


class Education(Base):
    """education 테이블. 학력 항목 하나가 행 하나에 대응한다."""

    __tablename__ = "education"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    school: Mapped[str] = mapped_column(Text)
    degree: Mapped[str] = mapped_column(Text)
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
