"""education 기능의 API 요청/응답 DTO."""
from datetime import date

from pydantic import BaseModel, ConfigDict, Field


class EducationResponse(BaseModel):
    """학력 항목 응답 형식."""

    model_config = ConfigDict(from_attributes=True)

    id: int = Field(description="학력 항목 고유 ID")
    school: str = Field(description="학교명")
    degree: str = Field(description="학위 또는 전공 (예: 컴퓨터공학 학사)")
    start_date: date = Field(description="입학일 또는 시작일")
    end_date: date | None = Field(default=None, description="졸업일 또는 종료일. 재학 중이면 null")
    description: str | None = Field(default=None, description="추가 설명 (선택)")


class EducationWriteRequest(BaseModel):
    """`POST /education`, `PUT /education/{education_id}` 요청 바디에 공통으로 쓰이는 입력."""

    school: str = Field(description="학교명")
    degree: str = Field(description="학위 또는 전공 (예: 컴퓨터공학 학사)")
    start_date: date = Field(description="입학일 또는 시작일")
    end_date: date | None = Field(default=None, description="졸업일 또는 종료일. 재학 중이면 생략")
    description: str | None = Field(default=None, description="추가 설명 (선택)")
