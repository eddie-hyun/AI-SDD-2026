"""education 기능의 API 엔드포인트: 목록 조회, 생성, 수정, 삭제."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from db import get_db
from features.auth.service import require_admin

from .models import Education
from .schemas import EducationResponse, EducationWriteRequest

router = APIRouter(prefix="/education", tags=["education"])


@router.get("", response_model=list[EducationResponse])
def list_education_entries(db: Session = Depends(get_db)) -> list[EducationResponse]:
    """모든 학력 항목을 시작일 최신순으로 반환한다. 로그인 여부와 관계없이 누구나 조회할 수 있다."""
    entries = db.query(Education).order_by(Education.start_date.desc()).all()
    return [EducationResponse.model_validate(entry) for entry in entries]


@router.post("", response_model=EducationResponse, status_code=201)
def create_education_entry(
    payload: EducationWriteRequest,
    db: Session = Depends(get_db),
    _admin: None = Depends(require_admin),
) -> EducationResponse:
    """로그인한 관리자가 새 학력 항목을 추가한다."""
    entry = Education(**payload.model_dump())
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return EducationResponse.model_validate(entry)


@router.put("/{education_id}", response_model=EducationResponse)
def update_education_entry(
    education_id: int,
    payload: EducationWriteRequest,
    db: Session = Depends(get_db),
    _admin: None = Depends(require_admin),
) -> EducationResponse:
    """로그인한 관리자가 기존 학력 항목의 내용을 전체 수정한다."""
    entry = db.get(Education, education_id)
    if entry is None:
        raise HTTPException(status_code=404, detail="학력 항목을 찾을 수 없습니다.")

    for field, value in payload.model_dump().items():
        setattr(entry, field, value)
    db.commit()
    db.refresh(entry)

    return EducationResponse.model_validate(entry)


@router.delete("/{education_id}", status_code=204)
def delete_education_entry(
    education_id: int,
    db: Session = Depends(get_db),
    _admin: None = Depends(require_admin),
) -> None:
    """로그인한 관리자가 학력 항목을 삭제한다."""
    entry = db.get(Education, education_id)
    if entry is None:
        raise HTTPException(status_code=404, detail="학력 항목을 찾을 수 없습니다.")
    db.delete(entry)
    db.commit()
