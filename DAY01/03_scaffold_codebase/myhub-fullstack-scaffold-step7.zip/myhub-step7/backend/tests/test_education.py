from fastapi.testclient import TestClient


def _entry_payload(**overrides: object) -> dict:
    payload = {
        "school": "테스트대학교",
        "degree": "테스트학과 학사",
        "start_date": "2020-03-01",
        "end_date": "2024-02-28",
        "description": "테스트 설명",
    }
    payload.update(overrides)
    return payload


def test_list_education_is_public_and_starts_empty(client: TestClient) -> None:
    response = client.get("/education")

    assert response.status_code == 200
    assert response.json() == []


def test_create_requires_login(client: TestClient) -> None:
    response = client.post("/education", json=_entry_payload())

    assert response.status_code == 401


def test_admin_can_create_update_and_delete_entry(admin_client: TestClient) -> None:
    create_response = admin_client.post("/education", json=_entry_payload(school="A대학교"))
    assert create_response.status_code == 201
    entry_id = create_response.json()["id"]

    list_response = admin_client.get("/education")
    assert [entry["school"] for entry in list_response.json()] == ["A대학교"]

    update_response = admin_client.put(f"/education/{entry_id}", json=_entry_payload(school="B대학교"))
    assert update_response.status_code == 200
    assert update_response.json()["school"] == "B대학교"

    delete_response = admin_client.delete(f"/education/{entry_id}")
    assert delete_response.status_code == 204

    assert admin_client.get("/education").json() == []


def test_list_is_ordered_by_start_date_descending(admin_client: TestClient) -> None:
    admin_client.post("/education", json=_entry_payload(school="먼저 입학", start_date="2015-03-01"))
    admin_client.post("/education", json=_entry_payload(school="나중 입학", start_date="2021-03-01"))

    response = admin_client.get("/education")

    assert [entry["school"] for entry in response.json()] == ["나중 입학", "먼저 입학"]
