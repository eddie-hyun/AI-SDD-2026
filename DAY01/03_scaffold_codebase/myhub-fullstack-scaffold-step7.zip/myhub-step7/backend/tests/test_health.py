from fastapi.testclient import TestClient


def test_health_reports_connected_database(client: TestClient) -> None:
    response = client.get("/health")

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["database_status"] == "connected"
    assert isinstance(body["database_version"], str) and body["database_version"]
