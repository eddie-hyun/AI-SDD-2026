import os

from fastapi.testclient import TestClient


def test_login_with_correct_password_starts_session(client: TestClient) -> None:
    response = client.post("/auth/login", json={"password": os.environ["ADMIN_PASSWORD"]})

    assert response.status_code == 200
    assert response.json()["authenticated"] is True


def test_login_with_wrong_password_is_rejected(client: TestClient) -> None:
    response = client.post("/auth/login", json={"password": "wrong-password"})

    assert response.status_code == 401


def test_session_reflects_login_state(client: TestClient) -> None:
    assert client.get("/auth/session").json()["authenticated"] is False

    client.post("/auth/login", json={"password": os.environ["ADMIN_PASSWORD"]})

    assert client.get("/auth/session").json()["authenticated"] is True


def test_logout_clears_session(admin_client: TestClient) -> None:
    assert admin_client.get("/auth/session").json()["authenticated"] is True

    admin_client.post("/auth/logout")

    assert admin_client.get("/auth/session").json()["authenticated"] is False
