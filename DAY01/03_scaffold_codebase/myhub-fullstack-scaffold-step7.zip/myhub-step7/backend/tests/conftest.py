"""테스트 전용 환경 구성.

db.py는 모듈을 import하는 시점에 DATABASE_URL 등 환경변수를 읽어 엔진을 만든다.
그래서 main/db를 import하기 전에 반드시 테스트 전용 값으로 환경변수를 먼저 세팅해야 하며,
그래야만 .env에 설정된 실제 Supabase 데이터베이스를 절대 건드리지 않을 수 있다.
(python-dotenv의 load_dotenv()는 이미 설정된 환경변수를 덮어쓰지 않으므로, db.py/auth/service.py가
내부적으로 호출하는 load_dotenv()는 아래에서 세팅한 값을 그대로 유지해준다.)
"""
import atexit
import os
import sqlite3
import tempfile

_TEST_DB_FD, _TEST_DB_PATH = tempfile.mkstemp(suffix=".db")
os.close(_TEST_DB_FD)


def _cleanup_test_db() -> None:
    """엔진이 물고 있는 커넥션을 먼저 닫아야 Windows에서 임시 DB 파일을 지울 수 있다."""
    engine.dispose()
    if os.path.exists(_TEST_DB_PATH):
        os.remove(_TEST_DB_PATH)


os.environ["DATABASE_URL"] = f"sqlite:///{_TEST_DB_PATH}"
os.environ.setdefault("ADMIN_PASSWORD", "test-admin-password")
os.environ.setdefault("SESSION_SECRET_KEY", "test-session-secret-key")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import BigInteger, event  # noqa: E402
from sqlalchemy.ext.compiler import compiles  # noqa: E402

from db import Base, SessionLocal, engine  # noqa: E402
from main import app  # noqa: E402

atexit.register(_cleanup_test_db)


@event.listens_for(engine, "connect")
def _register_sqlite_version_function(dbapi_connection, connection_record) -> None:
    """/health가 실행하는 `SELECT version()`은 Postgres 전용 함수라 SQLite에는 없다.
    원본 코드(main.py)는 건드리지 않고, 테스트 DB 연결에만 흉내용 version() 함수를 등록해 맞춰준다.
    """
    if isinstance(dbapi_connection, sqlite3.Connection):
        dbapi_connection.create_function("version", 0, lambda: "SQLite (test database)")


@compiles(BigInteger, "sqlite")
def _compile_big_integer_as_integer_on_sqlite(type_, compiler, **kw) -> str:
    """SQLite는 컬럼 타입 이름이 정확히 'INTEGER'인 단일 PK만 자동증가(ROWID) 별칭으로 취급한다.
    엔티티(models.py)는 Postgres에 맞춰 BigInteger를 그대로 쓰므로, 원본 코드는 건드리지 않고
    테스트 DB(SQLite)에서 테이블을 만들 때만 'INTEGER'로 컴파일되도록 맞춰준다.
    """
    return "INTEGER"


@pytest.fixture(autouse=True)
def _fresh_schema():
    """테스트마다 스키마를 새로 만들고, 끝나면 지운다. 원본 앱 코드는 건드리지 않는다."""
    Base.metadata.create_all(engine)
    yield
    Base.metadata.drop_all(engine)


@pytest.fixture
def db_session():
    """테스트 데이터를 직접 넣고 뺄 때 쓰는 SQLAlchemy 세션."""
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture
def client() -> TestClient:
    """쿠키 저장소를 갖는 테스트 클라이언트. 테스트마다 새로 만들어져 로그인 상태가 서로 섞이지 않는다."""
    return TestClient(app)


@pytest.fixture
def admin_client(client: TestClient) -> TestClient:
    """로그인까지 마친 테스트 클라이언트. 관리자 전용 엔드포인트 테스트에 사용한다."""
    response = client.post("/auth/login", json={"password": os.environ["ADMIN_PASSWORD"]})
    assert response.status_code == 200
    return client
