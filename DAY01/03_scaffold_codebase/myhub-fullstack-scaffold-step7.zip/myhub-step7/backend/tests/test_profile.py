from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from features.profiles.models import Profile


def _seed_profile(db_session: Session) -> None:
    db_session.add(Profile(name="테스트 사용자", headline="테스트 한 줄 소개", bio="테스트 상세 소개"))
    db_session.commit()


def test_get_profile_without_data_returns_404(client: TestClient) -> None:
    response = client.get("/profile")

    assert response.status_code == 404


def test_get_profile_returns_seeded_data(client: TestClient, db_session: Session) -> None:
    _seed_profile(db_session)

    response = client.get("/profile")

    assert response.status_code == 200
    body = response.json()
    assert body["name"] == "테스트 사용자"
    assert body["headline"] == "테스트 한 줄 소개"


def test_update_profile_requires_login(client: TestClient, db_session: Session) -> None:
    _seed_profile(db_session)

    response = client.put("/profile", json={"name": "변경", "headline": "변경", "bio": "변경"})

    assert response.status_code == 401


def test_admin_can_update_profile(admin_client: TestClient, db_session: Session) -> None:
    _seed_profile(db_session)

    response = admin_client.put(
        "/profile",
        json={"name": "변경된 이름", "headline": "변경된 한 줄 소개", "bio": "변경된 상세 소개"},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["name"] == "변경된 이름"
    assert body["headline"] == "변경된 한 줄 소개"
