-- Step 2: profile 테이블 생성 + 초기 데이터 1건 + 외부 접근 잠금
-- Supabase 대시보드 > SQL Editor 에서 그대로 실행하세요.

-- 1) 테이블 생성
create table if not exists profile (
    id bigint generated always as identity primary key,
    name text not null,
    headline text not null,
    bio text not null,
    updated_at timestamptz not null default now()
);

-- 2) 초기 데이터 1건 입력 (원하는 값으로 바꿔서 실행하세요)
insert into profile (name, headline, bio)
values (
    '홍길동',
    '백엔드를 좋아하는 풀스택 개발자',
    '여기에 상세 소개를 자유롭게 작성하세요. 여러 문단이 될 수도 있습니다.'
);

-- 3) 바깥에서 못 보게 잠그기
-- Supabase Data API(PostgREST)는 anon/authenticated 역할로 테이블에 접근합니다.
-- 이 서버는 세션 풀러(직접 Postgres 연결)로 접속하므로 아래 잠금과 무관하게 계속 동작합니다.
alter table profile enable row level security;
revoke all on profile from anon, authenticated;
